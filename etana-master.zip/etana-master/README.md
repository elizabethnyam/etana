# Identity Box

Identity Box aims at bringing the power of decentralized web to the user. Identity Box is all about data, security, and privacy.

Feel free to consult our [documentation](https://idbox.online/identity-box).
