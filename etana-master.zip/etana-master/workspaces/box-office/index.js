#!/usr/bin/env node

import { main } from './source/main.js'

main()
