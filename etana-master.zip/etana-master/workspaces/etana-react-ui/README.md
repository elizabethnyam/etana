# @identity-box/idbox-react-ui

`@identity-box/idbox-react-ui` provides ui components that make building React client apps
a bit easier.