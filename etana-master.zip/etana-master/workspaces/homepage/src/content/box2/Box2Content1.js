import { TextBox } from 'src/components/ui-blocks'

const Box2Content1 = () => (
  <TextBox>
    The society is becoming increasingly more aware of the importance
    of protecting the digital content and it is becoming clear that
    the current centralized model has came to an end.
  </TextBox>
)

export { Box2Content1 }
