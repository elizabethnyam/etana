import Layout from '@confluenza/gatsby-theme-confluenza/src/layouts'

export default Layout
