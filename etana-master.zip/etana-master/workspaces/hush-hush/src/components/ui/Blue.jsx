const Blue = ({ children }) => (
  <span className='text-[#0099FF]'>{children}</span>
)

export { Blue }
