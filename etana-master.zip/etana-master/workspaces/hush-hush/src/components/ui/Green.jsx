const Green = ({ children }) => (
  <span style={{ color: 'LimeGreen' }}>{children}</span>
)

export { Green }
