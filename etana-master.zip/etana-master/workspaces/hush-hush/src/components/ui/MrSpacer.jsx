const MrSpacer = ({ space }) => (
  <div className='w-[1px]' style={{ height: space }} />
)

export { MrSpacer }
