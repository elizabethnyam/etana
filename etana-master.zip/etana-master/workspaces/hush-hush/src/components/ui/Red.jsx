const Red = ({ children }) => (
  <span className='text-[red]'>{children}</span>
)

export { Red }
