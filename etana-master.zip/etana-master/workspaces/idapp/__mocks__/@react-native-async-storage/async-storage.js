export default from '@react-native-async-storage/async-storage/jest/async-storage-mock'
