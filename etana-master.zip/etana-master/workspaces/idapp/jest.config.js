module.exports = {
  preset: 'jest-expo'
}
