---
path: /components/rendezvous-client
title: Rendezvous Client
tag: component
content: README.md
sortIndex: 20
---
