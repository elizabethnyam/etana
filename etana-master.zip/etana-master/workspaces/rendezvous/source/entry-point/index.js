export { EntryPoint } from './EntryPoint.js'
