export { StateSerializer } from './StateSerializer.js'
